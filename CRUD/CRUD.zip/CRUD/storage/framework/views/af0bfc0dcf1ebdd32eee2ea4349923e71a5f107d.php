;

<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <section id="main-content">
        <div class="wrapper">
            <div class="row">
                <h3 class="page-header"><i class="icon_document_alt"></i>Riwayat Hidup</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><i class="fa fa-home"></i><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><i class="icon_document_alt"></i><a href="">Riwayat Hidup</a></li>
                    <li class="breadcrumb-item"><i class="fa fa-files-o"></i><a href="">Pendidikan</a></li>
                </ul>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Pendidikan
                    </header>
                    <div class="panel-body">
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('pendidikan.create')); ?>">
                            <button class="btn btn-primary" type="button">
                                <i class="fa fa-plus"> Tambah </i> 
                            </button>
                        </a>
                            <br><br>
                            <table class="table table-striped table-advance table-hover">
                                <tbody>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Tingkatan</th>
                                        <th>Tahun Masuk</th>
                                        <th>Tahun Selesai</th>
                                        <th> Action </th>
                                    </tr>
                                    <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td>
                                                <?php if($item->tingkatan == 1): ?>
                                                    TK
                                                <?php elseif($item->tingkatan == 2): ?>
                                                    SD
                                                <?php elseif($item->tingkatan == 3): ?>
                                                    SMP
                                                <?php elseif($item->tingkatan == 4): ?>
                                                    SMA/SMK
                                                <?php elseif($item->tingkatan == 5): ?>
                                                    D3
                                                <?php elseif($item->tingkatan == 6): ?>
                                                    D4/S1
                                                <?php elseif($item->tingkatan == 7): ?>
                                                    S2
                                                <?php elseif($item->tingkatan == 8): ?>
                                                    S3
                                                <?php endif; ?>

                                            </td>
                                            <td><?php echo e($item->tahun_masuk); ?></td>
                                            <td><?php echo e($item->tahun_keluar); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('pendidikan.destroy', $item->id)); ?>" method="POST">
                                                    <div class="btn-group">
                                                    <a class="btn btn-warning" href="<?php echo e(route('pendidikan.edit', $item->id)); ?>"><i class="bi bi-pencil-square"></i></a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah anda yakin untuk menghapus data ini?')"><i class="bi bi-trash"></i></button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </section>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD\CRUD\resources\views/backend/pendidikan/index.blade.php ENDPATH**/ ?>