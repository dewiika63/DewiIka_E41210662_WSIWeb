<p align="center"><a href="#" target="_blank"><img src="https://pendasial.wstif3b.id/img/logo-sekolah.png" width="400" alt="SMK Darus Sholah"></a></p>

## About

Repositori ini digunakan untuk mengumpulkan dokumentasi hasil praktek pada BKPM Web Framework.

List tugas yang ada pada repositori ini:
- 
## Student Bio

NIM: E41210746
Nama: Moch. Iqbal Maulana Fiekri
Program Studi: Teknik Informatika
Angkatan: 2021